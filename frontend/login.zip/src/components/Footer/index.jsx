

export default function Footer() {
        return (
          
<div>
<div className="Copyright">LENSTAGS 2022 - Privacity Policy - Terms of Service</div>
</div>

        )
      }