

export default function Hero_Whats() {
        return (
          
<div>
<div className="Hero_Whats_logo">
<img id="about" src="/img/logo.png" alt="" width="400" height="auto"></img>
</div>

<div className="Whats_container">

<div className="Container_cards_wthas">

<div className="Cards_wthas">
<div className="Card_Whats_Text">
        <h3>What is Lenstags?</h3>
        <p> WE ARE A WEB3 SOCIAL NETWORK POWERED BY LENS FOCUSED ON ORGANIZING CONTENT BASED ON YOUR INTERESTS</p>
</div>
</div>

<div className="Cards_wthas">
<div className="Card_Whats_Text">
        <h3>What it is used for?</h3>
        <p> WITH LENSTAGS, YOU CAN DISCOVER, COLLECT AND ORGANIZE THE CONTENT THAT IS INTERESTING TO YOU AND SHARE IT WITH OTHERS!

</p>
</div>
</div>

<div className="Cards_wthas">
<div className="Card_Whats_Text">
        <h3>How can i learn with lenstags?</h3>
        <p> CREATE LEARNING PATHS BASED ON TAGS OF YOUR INTEREST.
COLLECT AND EXPAND YOUR KNOWLEDGE.
</p>
</div>
</div>

<div className="Cards_wthas">
<div className="Card_Whats_Text">
        <h3>How can an organization use lenstags?</h3>
        <p> REWARD PEOPLE  CURATING CONTENT RELATED TO YOUR ORGANIZATION, PRODUCT OR PROTOCOL.
GROW A HUB OF RESOURCES.



</p>
</div>
</div>

</div></div>

</div>

        )
      }