

export default function Nombre() {
        return (
          
<div>
Contenido
</div>

        )
      }