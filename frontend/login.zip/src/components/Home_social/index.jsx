

export default function Social() {
        return (
          
<div className="Contener_Redes">
       
<div>

        
<div className="Whats_container">

<div className="Container_cards_wthas">

<div className="Cards_wthas2">
<div className="Card_Whats_Text">
<img
                src="/icons/telegram.svg"
                width="44px"
                height="44px"
                alt="twitter"
              /></div>
</div>



<div className="Cards_wthas2">
<div className="Card_Whats_Text">
<img
                src="/icons/discord.svg"
                width="44px"
                height="44px"
                alt="discord"
              /></div>
</div>

<div className="Cards_wthas2">
<div className="Card_Whats_Text">
<img
                src="/icons/twitter.svg"
                width="44px"
                height="44px"
                alt="telegram"
              /></div>
</div>


</div></div>

</div>

</div>

        )
      }